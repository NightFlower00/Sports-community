import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { validateActivities } from "./catalogue.mjs";
const data = JSON.parse(
  await readFile(new URL("./data/activities.json", import.meta.url)),
);
test("accepts Eindhoven catalogue", () =>
  assert.equal(validateActivities(data).length, 6));
test("rejects duplicate IDs", () =>
  assert.throws(() => validateActivities([data[0], data[0]])));
test("rejects out-of-area activity", () =>
  assert.throws(() => validateActivities([{ ...data[0], latitude: 52.37 }])));
test("rejects missing host", () =>
  assert.throws(() => validateActivities([{ ...data[0], host: "" }])));
