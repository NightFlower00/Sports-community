// Domain validation is independent of HTTP and can be tested directly.
export function validateActivities(items) {
  if (!Array.isArray(items)) throw new Error("Expected an activity array");
  const ids = new Set();
  for (const item of items) {
    if (!item.activity || ids.has(item.activity))
      throw new Error("Duplicate or missing id");
    ids.add(item.activity);
    for (const key of ["sport", "location", "date", "time", "host"]) {
      if (typeof item[key] !== "string" || !item[key].trim())
        throw new Error("Missing " + key);
    }
    const lat = Number(item.latitude);
    const lon = Number(item.longitude);
    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lon) ||
      lat < 51.36 ||
      lat > 51.53 ||
      lon < 5.34 ||
      lon > 5.6
    ) {
      throw new Error("Activity must be within Eindhoven demo bounds");
    }
  }
  return items;
}
