import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { validateActivities } from "./catalogue.mjs";

const root = fileURLToPath(new URL("../", import.meta.url));
const activities = validateActivities(
  JSON.parse(
    await readFile(new URL("./data/activities.json", import.meta.url)),
  ),
);
const types = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "text/javascript",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
};

http
  .createServer(async (req, res) => {
    const send = (status, data) => {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(data));
    };
    if (req.method !== "GET" && req.method !== "HEAD")
      return send(405, { error: "Read-only service" });
    let pathname;
    try {
      pathname = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
    } catch {
      return send(400, { error: "Invalid URL" });
    }
    if (pathname === "/api/health") return send(200, { status: "ok" });
    if (pathname === "/api/activities") return send(200, { activities });
    // Explicit public-file allowlist prevents serving server code or configuration.
    const name = pathname === "/" ? "index.html" : pathname.slice(1);
    if (
      !["index.html", "style.css", "app.js", "theme.js"].includes(name) &&
      !(name.startsWith("assets/") && !name.split("/").includes(".."))
    ) {
      return send(404, { error: "Not found" });
    }
    try {
      const body = await readFile(path.join(root, name));
      res.writeHead(200, {
        "Content-Type": types[path.extname(name)] || "application/octet-stream",
        "X-Content-Type-Options": "nosniff",
      });
      res.end(req.method === "HEAD" ? undefined : body);
    } catch {
      send(404, { error: "Not found" });
    }
  })
  .listen(Number(process.env.PORT || 8080), "0.0.0.0");
