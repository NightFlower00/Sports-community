// Apply the saved appearance before the page is painted.
// With no saved preference, follow the operating-system appearance.
(() => {
  let savedTheme = null;
  try {
    savedTheme = JSON.parse(localStorage.getItem("sp-theme"));
  } catch {
    // Browser storage may be disabled; system preference still works.
  }
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const theme =
    savedTheme === "light" || savedTheme === "dark"
      ? savedTheme
      : prefersDark
        ? "dark"
        : "light";
  document.documentElement.dataset.theme = theme;
})();
