// ============================================================================
// DOM helpers: layouts, labels and demo content are defined in index.html.
// ============================================================================
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const app = $("#app");

function cloneTemplate(id) {
  return document.getElementById(id).content.cloneNode(true);
}
function text(key) {
  return document
    .querySelector(`#ui-text [data-text="${key}"]`)
    .textContent.trim();
}
function read(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) ?? fallback;
  } catch {
    return fallback;
  }
}
function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function fillText(selector, value, root = app) {
  $$(selector, root).forEach((element) => {
    element.textContent = value;
  });
}

// ============================================================================
// State and data. Initial activities and conversations are read from the HTML.
// Browser storage preserves changes, as in the previous version.
// ============================================================================
let users = read("sp-users", []);
let user = read("sp-session", null);
let page = user ? "home" : "login";
let selected = 0;
let upcomingSelected = 2;
let chatSelected = 0;
let month = 9;
let filterOpen = false;
let eventMap = null;
let joined = [];

function joinedStorageKey() {
  return "sp-joined-" + (user?.id || "guest");
}
function loadJoinedActivities() {
  const demoDefault =
    user?.id === "demo-dayah" ? read("sp-joined", [0, 1, 3, 5]) : [];
  joined = read(joinedStorageKey(), demoDefault);
}

const activityTemplate = document.getElementById("page-activities").content;
const sports = $$(".activity-card", activityTemplate).map((card) => ({
  ...card.dataset,
}));
let filters = sports.map((sport) => sport.sport);
const friends = $$(
  "[data-email]",
  document.getElementById("page-chat").content,
).map((friend) => ({ ...friend.dataset }));
const initialChats = $$("#chat-seed section").map((section) => ({
  name: section.dataset.name,
  sub: section.dataset.sub,
  messages: $$("p", section).map((message) => ({
    who: message.dataset.who,
    text: message.textContent,
  })),
}));
let chats = [];
let loadedAccountId = null;

// ============================================================================
// Appearance: remember a manual selection and otherwise follow system changes.
// Labels and button markup live in index.html.
// ============================================================================
function updateThemeControl() {
  const dark = document.documentElement.dataset.theme === "dark";
  const button = $("#theme-toggle");
  $("[data-theme-icon]", button).textContent = dark ? "☀" : "☾";
  $("[data-theme-label]", button).textContent = $(
    dark ? "[data-theme-light]" : "[data-theme-dark]",
  ).textContent;
  button.setAttribute(
    "aria-label",
    $(dark ? "[data-theme-to-light]" : "[data-theme-to-dark]").textContent,
  );
  button.setAttribute("aria-pressed", String(dark));
}

function toggleTheme() {
  const next =
    document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try {
    save("sp-theme", next);
  } catch {
    /* Current selection still applies. */
  }
  updateThemeControl();
}

window
  .matchMedia("(prefers-color-scheme: dark)")
  .addEventListener("change", (event) => {
    if (read("sp-theme", null)) return;
    document.documentElement.dataset.theme = event.matches ? "dark" : "light";
    updateThemeControl();
  });

// ============================================================================
// Navigation and shared UI
// ============================================================================
function go(nextPage, activityIndex) {
  if (activityIndex !== undefined) selected = activityIndex;
  page = nextPage;
  filterOpen = false;
  render();
  window.scrollTo(0, 0);
}
function toast(message) {
  const notification = $("#toast");
  notification.textContent = message;
  notification.style.display = "block";
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => {
    notification.style.display = "none";
  }, 4000);
}
function openDialog(name) {
  const dialog = $("#modal");
  dialog.replaceChildren(cloneTemplate("dialog-" + name));
  dialog.showModal();
}
function render() {
  loadPersonalContext();
  loadJoinedActivities();
  updateThemeControl();
  const isAuth = page === "login" || page === "signup";
  if (!document.getElementById("page-" + page)) page = "home";
  releaseEventMap();
  const themeControl = $("#theme-toggle");
  document.body.append(themeControl);
  app.replaceChildren();
  app.append(cloneTemplate(isAuth ? "shared-auth-header" : "shared-header"));
  $("header .right").prepend(themeControl);
  app.append(cloneTemplate("page-" + page));
  if (!isAuth) {
    app.append(cloneTemplate("shared-footer"));
    updateSharedProfile();
    $$("nav button").forEach((button) => {
      button.classList.toggle(
        "active",
        button.textContent.trim().toLowerCase() === page,
      );
    });
  }
  if (page === "home") updateHome();
  if (page === "activities") updateActivities();
  if (page === "chat") updateChat();
  if (page === "profile") updateProfile();
  fillText("[data-friend-count]", ownFriendEmails().length);
  const notificationDot = $(".red-dot");
  if (notificationDot) notificationDot.hidden = user?.id !== "demo-dayah" && !read(applicationNotificationKey(), []).length;
  if (page === "notifications") renderApplicationNotifications();
}
function updateSharedProfile() {
  if (!user) return;
  fillText("[data-user-name]", user.name);
  $$(".profilebutton img, .profile-photo").forEach((image) => {
    image.src = profilePhotoSource(user);
  });
}

// ============================================================================
// Home: greeting, filters, coloured map markers and radar information
// ============================================================================
function updateHome() {
  const greeting = $("[data-greeting]");
  greeting.textContent =
    greeting.dataset.prefix + user.name.split(" ")[0] + greeting.dataset.suffix;
  updateRadar();
  updatePersonalHome();
}
function updateRadar() {
  const map = $("#radar");
  const filter = $(".filter", map);
  filter.textContent = text("filter-label") + " (" + filters.length + ")";
  filter.setAttribute("aria-expanded", String(filterOpen));
  const slot = $("[data-filter-slot]", map);
  slot.replaceChildren();
  if (filterOpen) {
    const options = cloneTemplate("map-filters");
    $$("input", options).forEach((input) => {
      input.checked = filters.includes(input.dataset.sport);
    });
    slot.append(options);
  }
  updateRadarInformation();
  const visible = sports
    .map((sport, index) => index)
    .filter((index) => filters.includes(sports[index].sport));
  showEventMap(map, visible, false);
}

function updateRadarInformation() {
  const info = $("#radar-info");
  info.replaceChildren();
  if (filters.length) info.append(cloneTemplate("radar-info-" + selected));
  else info.textContent = text("no-sport");
}

function toggleFilters() {
  filterOpen = !filterOpen;
  updateRadar();
}
function filterSport(sport, checked) {
  filters = checked
    ? [...new Set([...filters, sport])]
    : filters.filter((value) => value !== sport);
  if (!filters.includes(sports[selected].sport)) {
    selected = Math.max(
      0,
      sports.findIndex((value) => filters.includes(value.sport)),
    );
  }
  updateRadar();
}
function selectMap(index, single) {
  selected = index;
  if (single) {
    updateActivities();
    $("#location-details").scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  } else updateRadar();
}

// ============================================================================
// Geographic Eindhoven maps (Leaflet + PDOK / Kadaster)
// The demo event coordinates live on the activity cards in index.html.
// ============================================================================
function releaseEventMap() {
  if (!eventMap) return;
  eventMap.map.remove();
  eventMap = null;
}

function showEventMap(container, indices, single) {
  const canvas = $("[data-map-canvas]", container);
  const status = $("[data-map-status]", container);
  if (!window.L) {
    status.textContent = text("map-unavailable");
    status.hidden = false;
    return;
  }

  let fresh = !eventMap || eventMap.canvas !== canvas;
  if (fresh) {
    releaseEventMap();
    const map = L.map(canvas, {
      center: [51.44, 5.475],
      zoom: 13,
      minZoom: 11,
      maxZoom: 18,
      scrollWheelZoom: false,
      zoomControl: false,
      attributionControl: false,
      maxBounds: [
        [51.36, 5.34],
        [51.53, 5.6],
      ],
      maxBoundsViscosity: 0.8,
    });
    L.control.zoom({ position: "topright" }).addTo(map);
    const attribution = document.getElementById(
      "event-map-attribution",
    ).innerHTML;
    const credits = $("[data-map-credits]", container);
    if (credits)
      credits.replaceChildren(cloneTemplate("event-map-attribution"));
    const tiles = L.tileLayer(
      "https://service.pdok.nl/kadaster/brt-achtergrondkaart/wmts/v2_0/standaard/EPSG:3857/{z}/{x}/{y}.png",
      {
        maxZoom: 19,
        attribution,
        referrerPolicy: "strict-origin-when-cross-origin",
      },
    ).addTo(map);
    let loaded = 0;
    let failed = 0;
    tiles.on("tileload", () => {
      loaded++;
      status.hidden = true;
    });
    tiles.on("tileerror", () => {
      failed++;
      if (!loaded && failed >= 2) status.hidden = false;
    });
    eventMap = { map, canvas, layers: L.layerGroup().addTo(map), markers: [] };
  }

  eventMap.layers.clearLayers();
  eventMap.markers = [];
  const bounds = [];
  indices.forEach((index) => {
    const sport = sports[index];
    const point = [Number(sport.latitude), Number(sport.longitude)];
    bounds.push(point);
    L.circle(point, {
      radius: 130,
      color: sport.color,
      fillColor: sport.color,
      fillOpacity: 0.12,
      weight: 2,
      interactive: false,
    }).addTo(eventMap.layers);

    const pin = cloneTemplate("event-map-pin").firstElementChild;
    pin.style.setProperty("--pin-color", sport.color);
    $("[data-pin-number]", pin).textContent = index + 1;
    const icon = L.divIcon({
      className: "event-marker" + (index === selected ? " selected" : ""),
      html: pin,
      iconSize: [36, 46],
      iconAnchor: [18, 44],
      popupAnchor: [0, -42],
      tooltipAnchor: [0, -40],
    });
    const marker = L.marker(point, {
      icon,
      title: sport.sport + " • " + sport.location + ", Eindhoven",
      alt: sport.sport + " event pin",
      keyboard: true,
    }).addTo(eventMap.layers);

    const popup = cloneTemplate("event-map-popup").firstElementChild;
    fillText("[data-event-sport]", sport.sport, popup);
    fillText("[data-event-location]", sport.location + ", Eindhoven", popup);
    fillText("[data-event-date]", sport.date + " • " + sport.time, popup);
    fillText("[data-event-host]", sport.host, popup);
    $("[data-event-details]", popup).addEventListener("click", () =>
      go("activities", index),
    );
    marker.bindPopup(popup, { minWidth: 220, maxWidth: 300 });
    const label = document.createElement("span");
    label.textContent = sport.sport + " • " + sport.location;
    marker.bindTooltip(label, { direction: "top", permanent: single });
    marker.on("click", () => {
      selected = index;
      eventMap.markers.forEach((item) =>
        item.marker
          .getElement()
          ?.classList.toggle("selected", item.index === index),
      );
      if (page === "home") updateRadarInformation();
    });
    eventMap.markers.push({ index, marker });
  });

  if (single && bounds.length) eventMap.map.setView(bounds[0], 16);
  else if (fresh && bounds.length)
    eventMap.map.fitBounds(bounds, { padding: [55, 55], maxZoom: 13 });
  requestAnimationFrame(() => eventMap?.map.invalidateSize());
}

// ============================================================================
// Activities: selection, session details, joining and upcoming information
// ============================================================================
function updateActivities() {
  $$(".activity-card", app).forEach((card, index) => {
    const active = index === selected;
    card.classList.toggle("selected", active);
    const button = $("button", card);
    button.textContent = text(active ? "selected" : "view-details");
    const isJoined = joined.includes(index);
    const status = $("[data-join-status]", card);
    status.classList.toggle("is-joined", isJoined);
    status.classList.toggle("is-not-joined", !isJoined);
    $("[data-status-icon]", status).textContent = isJoined ? "✓" : "○";
    $("[data-status-label]", status).textContent = text(
      isJoined ? "confirmed" : "not-joined",
    );
    const activeLabel = $('small[style*="float"]', card);
    if (activeLabel) activeLabel.hidden = !active;
  });
  const slot = $("#activity-details-slot");
  releaseEventMap();
  slot.replaceChildren(cloneTemplate("activity-detail-" + selected));
  showEventMap($("#location-map", slot), [selected], true);
  const button = $("[data-join-button]", slot);
  const isJoined = joined.includes(selected);
  button.textContent = text(isJoined ? "leave" : "join");
  button.classList.toggle("lime", isJoined);
  $("[data-participant-count]", slot).textContent =
    (isJoined ? 8 : 7) + text("spots");
  updateUpcoming();
}
function chooseActivity(index) {
  selected = index;
  updateActivities();
  $("#location-details").scrollIntoView({
    behavior: "smooth",
    block: "center",
  });
}
function joinActivity() {
  const wasJoined = joined.includes(selected);
  joined = wasJoined
    ? joined.filter((index) => index !== selected)
    : [...joined, selected];
  save(joinedStorageKey(), joined);
  if (!wasJoined) {
    const entries = read(applicationNotificationKey(), []);
    entries.unshift({
      sport: sports[selected].sport,
      location: sports[selected].location,
      date: sports[selected].date,
      time: sports[selected].time,
      createdAt: new Date().toISOString(),
    });
    save(applicationNotificationKey(), entries);
  }
  updateActivities();
  toast(text(wasJoined ? "activity-left" : "activity-joined"));
}
function chooseUpcoming(index) {
  upcomingSelected = index;
  updateUpcoming();
}
function updateUpcoming() {
  $("#upcoming-info").replaceChildren(
    cloneTemplate("upcoming-info-" + upcomingSelected),
  );
  $$("[data-upcoming]", app).forEach((button) => {
    button.classList.toggle(
      "selected",
      Number(button.dataset.upcoming) === upcomingSelected,
    );
  });
}

// ============================================================================
// Chat: use HTML templates for conversations, messages and attachments
// ============================================================================
function updateChat() {
  const emails = ownFriendEmails();
  $$(".friends-row [data-email]").forEach((button) => {
    button.hidden = !emails.includes(button.dataset.email);
  });
  if (!chats.length) {
    $(".conversation-head h3").textContent = "Your conversations";
    $(".conversation-head small").textContent = "";
    $("#messages").replaceChildren(cloneTemplate("empty-personal-chat"));
    $(".composer").hidden = true;
    renderChatItems();
    return;
  }
  $(".composer").hidden = false;
  chatSelected = Math.min(chatSelected, chats.length - 1);
  const conversation = chats[chatSelected];
  $(".conversation-head h3").textContent = conversation.name;
  $(".conversation-head small").textContent = conversation.sub;
  renderChatItems($("#chat-search").value);
  renderMessages();
}
function renderChatItems(query = "") {
  const container = $("#chat-items");
  container.replaceChildren();
  chats.forEach((chat, index) => {
    if (!chat.name.toLowerCase().includes(query.toLowerCase())) return;
    const fragment = cloneTemplate("chat-item");
    const button = $("button", fragment);
    button.classList.toggle("selected", index === chatSelected);
    button.addEventListener("click", () => selectChat(index));
    fillText(
      "[data-chat-initials]",
      chat.name.slice(0, 2).toUpperCase(),
      fragment,
    );
    fillText("[data-chat-name]", chat.name, fragment);
    fillText(
      "[data-chat-preview]",
      (chat.messages.at(-1)?.text || text("start-chat")).slice(0, 76),
      fragment,
    );
    container.append(fragment);
  });
  if (!container.children.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = text("empty-chats");
    container.append(empty);
  }
}
function searchChats(query) {
  renderChatItems(query);
}
function selectChat(index) {
  chatSelected = index;
  updateChat();
}
function renderMessages() {
  const container = $("#messages");
  container.replaceChildren(cloneTemplate("chat-title"));
  chats[chatSelected].messages.forEach((message) => {
    const fragment = cloneTemplate("chat-message");
    const ownMessage = message.who === text("self");
    $("[data-message-label]", fragment).style.textAlign = ownMessage
      ? "right"
      : "left";
    $(".bubble", fragment).classList.toggle("mine", ownMessage);
    fillText("[data-message-author]", message.who, fragment);
    fillText("[data-message-time]", message.time || "3:01 PM", fragment);
    fillText("[data-message-text]", message.text, fragment);
    if (message.file) {
      $("[data-attachment]", fragment).hidden = false;
      const link = $("[data-file-link]", fragment);
      link.href = message.file;
      link.download = message.filename;
      fillText("[data-filename]", message.filename, fragment);
      if (message.type?.startsWith("image/")) {
        const image = $("[data-file-image]", fragment);
        image.hidden = false;
        image.src = message.file;
        image.alt = message.filename;
      }
    }
    container.append(fragment);
  });
  container.scrollTop = container.scrollHeight;
}
function updateMessages() {
  save(personalChatKey(), chats);
  renderMessages();
  renderChatItems($("#chat-search").value);
}
function sendMessage(event) {
  event.preventDefault();
  const input = $("#message-input");
  const message = input.value.trim();
  if (!message) return;
  chats[chatSelected].messages.push({
    who: text("self"),
    text: message,
    time: new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    }),
  });
  input.value = "";
  updateMessages();
}
function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
async function attachFiles(files) {
  for (const file of files) {
    if (file.size > 1500000) {
      toast(text("file-large"));
      continue;
    }
    const data = await readFile(file);
    chats[chatSelected].messages.push({
      who: text("self"),
      text: text("attachment"),
      file: data,
      filename: file.name,
      type: file.type,
    });
    try {
      updateMessages();
    } catch {
      chats[chatSelected].messages.pop();
      renderMessages();
      toast(text("storage-full"));
    }
  }
}
function openFriend(index) {
  const friend = friends[index];
  if (!friend) return;
  if (user.id !== "demo-dayah" && !ownFriendEmails().includes(friend.email)) {
    user.friendEmails = [...ownFriendEmails(), friend.email];
    persistUser();
  }
  let conversation = chats.findIndex((chat) => chat.name === friend.name);
  if (conversation < 0) {
    chats.push({ name: friend.name, sub: friend.email, messages: [] });
    conversation = chats.length - 1;
    save(personalChatKey(), chats);
  }
  chatSelected = conversation;
  go("chat");
}
function addFriend() {
  openDialog("add-friend");
}
function findFriend(event) {
  event.preventDefault();
  const email = $("#friend-email").value.trim().toLowerCase();
  const index = friends.findIndex((friend) => friend.email === email);
  const container = $("#friend-result");
  container.replaceChildren();
  if (index < 0) {
    container.textContent = text("friend-missing");
    return;
  }
  const fragment = cloneTemplate("friend-found");
  fillText("[data-friend-name]", friends[index].name, fragment);
  fillText("[data-friend-email]", friends[index].email, fragment);
  $("[data-open-friend]", fragment).addEventListener("click", () => {
    $("#modal").close();
    openFriend(index);
  });
  container.append(fragment);
}

// ============================================================================
// Profile: personal information, photo editing and calendar
// ============================================================================
function updateProfile() {
  updateSharedProfile();
  const handle = $("[data-user-handle]");
  // Preserve the location span already written in the HTML.
  handle.firstChild.textContent = "@" + user.username + " • ";
  fillText(
    "[data-about-title]",
    text("about-prefix") + " " + user.name.split(" ")[0].toUpperCase(),
  );
  fillText(
    "[data-user-about]",
    user.about ||
      (user.id === "demo-dayah"
        ? text("default-about")
        : $("[data-personal-about]", document).textContent),
  );
  const container = $("[data-user-sports]");
  container.replaceChildren();
  (user.sports || []).forEach((sport) => {
    const fragment = cloneTemplate("profile-sport");
    $(".pill", fragment).textContent = sport;
    container.append(fragment);
  });
  updateCalendar();
  updatePersonalProfile();
}
function changeMonth(value) {
  month = Number(value);
  updateCalendar();
}
function updateCalendar() {
  $('[aria-label="Choose calendar month"]').value = month;
  fillText(
    "[data-calendar-title]",
    new Date(2026, month).toLocaleString("en", { month: "long" }) + " 2026",
  );
  const container = $(".calendar");
  container.replaceChildren(cloneTemplate("calendar-weekdays"));
  const offset = (new Date(2026, month, 1).getDay() + 6) % 7;
  const days = new Date(2026, month + 1, 0).getDate();
  const attendance = [
    2, 3, 5, 7, 9, 10, 14, 16, 17, 20, 23, 24, 27, 29, 30, 31,
  ];
  for (let index = 0; index < offset; index++)
    container.append(cloneTemplate("calendar-empty"));
  for (let day = 1; day <= days; day++) {
    const fragment = cloneTemplate("calendar-day");
    const cell = $(".date", fragment);
    const attended =
      user.id === "demo-dayah"
        ? month >= 5 && attendance.includes(day)
        : personalAttendance().some((entry) => {
            const date = new Date(entry.completedAt);
            return (
              date.getFullYear() === 2026 &&
              date.getMonth() === month &&
              date.getDate() === day
            );
          });
    cell.textContent = day;
    cell.classList.toggle("attended", attended);
    cell.title = text(attended ? "attended" : "no-activity");
    container.append(fragment);
  }
}
function persistUser() {
  save("sp-session", user);
  const index = users.findIndex((account) => account.id === user?.id);
  if (index >= 0) {
    users[index] = { ...users[index], ...user };
    save("sp-users", users);
  }
}
async function changePhoto(file) {
  if (!file) return;
  const previousPhoto = user.photo;
  try {
    user.photo = await readProfilePhoto(file);
    persistUser();
    updateSharedProfile();
    toast(text("photo-saved"));
  } catch (failure) {
    user.photo = previousPhoto;
    toast(failure.message);
  }
}
function editProfile() {
  openDialog("edit-profile");
  $("#edit-name").value = user.name;
  $("#edit-username").value = user.username;
  $("#edit-sports").value = (user.sports || []).join(", ");
  $("#edit-about").value = user.about || "";
}
function saveProfile(event) {
  event.preventDefault();
  const username = $("#edit-username").value.trim();
  if (taken(username, user.id)) {
    $("#edit-error").textContent = text("username-used");
    return;
  }
  user = {
    ...user,
    name: $("#edit-name").value.trim(),
    username,
    sports: $("#edit-sports")
      .value.split(",")
      .map((sport) => sport.trim())
      .filter(Boolean),
    about: $("#edit-about").value,
  };
  persistUser();
  $("#modal").close();
  updateProfile();
  toast(text("profile-saved"));
}

// ============================================================================
// Signup and login: validate fields and store browser-local demo accounts
// ============================================================================
function taken(username, id) {
  return (
    ["admin", "sportify", "bram", "elena", "lars"].includes(
      username.toLowerCase(),
    ) ||
    users.some(
      (account) =>
        account.username.toLowerCase() === username.toLowerCase() &&
        account.id !== id,
    )
  );
}
function passwordRules(password) {
  return [
    password.length >= 10,
    /[A-Z]/.test(password),
    /[a-z]/.test(password),
    /\d/.test(password),
    /[^A-Za-z0-9\s]/.test(password),
  ];
}
function passwordFeedback(password) {
  const rules = passwordRules(password);
  const score = rules.filter(Boolean).length;
  $$("[data-rule]", app).forEach((label, index) => {
    label.classList.toggle("ok", rules[index]);
    label.textContent = (rules[index] ? "✓ " : "✕ ") + label.dataset.label;
  });
  const bar = $("#strength-bar");
  bar.style.width = (score / 5) * 100 + "%";
  bar.style.background = "#685bc7";
  $("#strength-text").textContent =
    text("strength-prefix") +
    " " +
    text(score === 5 ? "strong" : score >= 4 ? "medium" : "weak");
}
function checkUsername(value) {
  const invalid = !/^[A-Za-z0-9_]{3,24}$/.test(value);
  const used = taken(value);
  const status = $("#username-status");
  status.textContent = text(
    invalid ? "username-format" : used ? "username-used" : "username-available",
  );
  status.style.color = invalid || used ? "#b32b15" : "#37823e";
}
function togglePassword(button) {
  const input = $("#password");
  input.type = input.type === "password" ? "text" : "password";
  // Accessible labels live on this button's HTML data attributes.
  button.setAttribute(
    "aria-label",
    input.type === "password" ? button.dataset.show : button.dataset.hide,
  );
  button
    .querySelector(".eye-slash")
    .toggleAttribute("hidden", input.type === "password");
  button.setAttribute("aria-pressed", String(input.type === "text"));
}
async function hashPassword(password, salt) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new TextEncoder().encode(salt),
      iterations: 100000,
      hash: "SHA-256",
    },
    key,
    256,
  );
  return [...new Uint8Array(bits)]
    .map((value) => value.toString(16).padStart(2, "0"))
    .join("");
}
async function submitAuth(event, signup) {
  event.preventDefault();
  const error = $("#auth-error");
  error.textContent = "";
  const email = $("#email").value.trim().toLowerCase();
  const password = $("#password").value;
  if (!crypto.subtle || !crypto.randomUUID) {
    error.textContent = text("auth-unavailable");
    return;
  }
  if (signup) {
    const username = $("#username").value.trim();
    const favoriteSports = $$('[name="sport"]:checked', app).map(
      (input) => input.value,
    );
    if (taken(username)) {
      error.textContent = text("username-used");
      return;
    }
    if (users.some((account) => account.email === email)) {
      error.textContent = text("email-used");
      return;
    }
    if (passwordRules(password).some((rule) => !rule)) {
      error.textContent = text("password-rules");
      return;
    }
    if (!favoriteSports.length) {
      error.textContent = text("sport-required");
      return;
    }
    let photo = null;
    const photoFile = $("#signup-photo").files[0];
    if (photoFile) {
      try {
        photo = await readProfilePhoto(photoFile);
      } catch (failure) {
        error.textContent = failure.message;
        return;
      }
    }
    const salt = crypto.randomUUID();
    const hash = await hashPassword(password, salt);
    const account = {
      id: crypto.randomUUID(),
      name: $("#first").value.trim() + " " + $("#last").value.trim(),
      username,
      email,
      sports: favoriteSports,
      photo,
      about: "",
      attendance: [],
      friendEmails: [],
      createdAt: new Date().toISOString(),
      salt,
      hash,
    };
    users.push(account);
    save("sp-users", users);
    user = null;
    localStorage.removeItem("sp-session");
    go("login");
    $("#email").value = email;
    toast("Account created. Please log in with your new password.");
    return;
  } else {
    const account = users.find(
      (account) =>
        account.email === email || account.username.toLowerCase() === email,
    );
    if (
      !account ||
      (await hashPassword(password, account.salt)) !== account.hash
    ) {
      error.textContent = text("login-error");
      return;
    }
    user = { ...account };
  }
  delete user.salt;
  delete user.hash;
  persistUser();
  go("home");
}
function demoLogin() {
  const profile = document.getElementById("page-profile").content;
  user = {
    id: "demo-dayah",
    name: text("demo-name"),
    username: text("demo-username"),
    sports: $$(".sports-pills .pill", profile).map((pill) =>
      pill.textContent.trim(),
    ),
  };
  persistUser();
  if ($("#modal").open) $("#modal").close();
  go("home");
}
function socialDemo(provider) {
  openDialog("social");
  $("#modal h2").textContent = provider + " " + text("social-title-suffix");
  $("#modal p").textContent =
    text("social-description-prefix") +
    " " +
    provider +
    " " +
    text("social-description-suffix");
}
function forgotPassword() {
  openDialog("forgot-password");
}
function logout() {
  user = null;
  save("sp-session", null);
  go("login");
}

// Small event handlers keep implementation code out of the HTML attributes.
function closeDialog() {
  $("#modal").close();
}
function openAttachments() {
  $("#attachment").click();
}
function addEmoji() {
  $("#message-input").value += " 😊";
}
function handleActivityClick(event, index) {
  if (!event.target.closest("button")) chooseActivity(index);
}

// ============================================================================
// Event connections. HTML names an action; JavaScript implements that action.
// Delegation also works for content copied from any HTML template.
// ============================================================================
const actions = {
  exportActivities,
  toggleTheme,
  go,
  demoLogin,
  logout,
  chooseActivity,
  chooseUpcoming,
  selectMap,
  toggleFilters,
  joinActivity,
  openFriend,
  addFriend,
  editProfile,
  socialDemo,
  forgotPassword,
  closeDialog,
  openAttachments,
  addEmoji,
};
document.addEventListener("click", (event) => {
  const control = event.target.closest("[data-click]");
  if (!control) return;
  const args = JSON.parse(control.dataset.arguments || "[]");
  if (control.dataset.click === "togglePassword") togglePassword(control);
  else if (control.dataset.click === "handleActivityClick")
    handleActivityClick(event, ...args);
  else actions[control.dataset.click]?.(...args);
});
document.addEventListener("input", (event) => {
  const control = event.target;
  const handlers = { checkUsername, passwordFeedback, searchChats };
  handlers[control.dataset.input]?.(control.value);
});
document.addEventListener("change", (event) => {
  const control = event.target;
  switch (control.dataset.change) {
    case "attachFiles":
      attachFiles(control.files);
      break;
    case "previewSignupPhoto":
      previewSignupPhoto(control);
      break;
    case "changePhoto":
      changePhoto(control.files[0]);
      break;
    case "changeMonth":
      changeMonth(control.value);
      break;
    case "filterSport":
      filterSport(control.dataset.sport, control.checked);
      break;
  }
});
document.addEventListener("submit", (event) => {
  const form = event.target;
  const handlers = { sendMessage, findFriend, saveProfile, submitAuth };
  const handler = handlers[form.dataset.submit];
  if (handler) handler(event, ...JSON.parse(form.dataset.arguments || "[]"));
});

// Start the application after the HTML has loaded (the script uses defer).
render();

// Export only activity information and joined status; never account credentials.
function exportActivities() {
  const rows = sports.map((sport, index) => ({
    sport: sport.sport,
    location: sport.location + ", Eindhoven",
    date: sport.date,
    time: sport.time,
    host: sport.host,
    latitude: Number(sport.latitude),
    longitude: Number(sport.longitude),
    joined: joined.includes(index),
  }));
  const data = {
    description:
      "Fictional Eindhoven activities; approximate event coordinates.",
    exportedAt: new Date().toISOString(),
    activities: rows,
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "sportify-activity-data.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// Optional same-origin API; Go Live and file:// retain the HTML demo catalogue.
async function loadActivityCatalogue() {
  if (!/^https?:$/.test(location.protocol)) return;
  try {
    const response = await fetch("/api/activities");
    if (!response.ok) return;
    const { activities } = await response.json();
    if (!Array.isArray(activities) || activities.length !== sports.length)
      return;
    activities.forEach((item) => {
      const index = sports.findIndex(
        (sport) => sport.activity === item.activity,
      );
      if (index >= 0) Object.assign(sports[index], item);
    });
    if (page === "activities" || page === "home") render();
  } catch {
    // Static preview remains functional when the optional server is unavailable.
  }
}
loadActivityCatalogue();

// Native details supplies keyboard support; dismiss profile options on Escape
// or when the user clicks elsewhere in the document.
document.addEventListener("click", (event) => {
  const menu = document.querySelector(".profile-menu[open]");
  if (menu && !menu.contains(event.target)) menu.open = false;
});
document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  const menu = document.querySelector(".profile-menu[open]");
  if (menu) {
    menu.open = false;
    menu.querySelector("summary").focus();
  }
});

// Each account keeps its own immediate application confirmations.
function applicationNotificationKey() {
  return "sp-application-notifications-" + (user?.id || "guest");
}
function renderApplicationNotifications() {
  const entries = read(applicationNotificationKey(), []);
  const slot = $("[data-new-notifications]");
  if (!slot) return;
  if (user.id !== "demo-dayah") {
    $$(".notification-main > .notification").forEach((item) => item.remove());
    if (!entries.length)
      slot.append(cloneTemplate("empty-personal-notifications"));
  }
  for (const entry of entries) {
    const item = cloneTemplate("application-notification");
    fillText(
      "[data-application-message]",
      `${entry.sport} · ${entry.location}, Eindhoven · ${entry.date} at ${entry.time}. You have applied.`,
      item,
    );
    fillText(
      "[data-application-time]",
      new Date(entry.createdAt).toLocaleString(),
      item,
    );
    slot.append(item);
  }
  fillText(
    "[data-notification-count]",
    entries.length + (user.id === "demo-dayah" ? 5 : 0),
  );
}

// The demo portrait belongs only to Dayah's demo account.
function profilePhotoSource(account) {
  return (
    account.photo ||
    (account.id === "demo-dayah"
      ? "assets/avatar.jpg"
      : "assets/default-avatar.svg")
  );
}

async function readProfilePhoto(file) {
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
    throw new Error("Choose a JPG, PNG or WebP image.");
  }
  if (file.size > 1500000) {
    throw new Error("Choose a photo smaller than 1.5 MB.");
  }
  const source = await readFile(file);
  const preview = new Image();
  preview.src = source;
  try {
    await preview.decode();
  } catch {
    throw new Error("This photo could not be opened. Choose another image.");
  }
  return source;
}

async function previewSignupPhoto(control) {
  const file = control.files[0];
  const preview = $("#signup-photo-preview");
  const error = $("#signup-photo-error");
  error.textContent = "";
  preview.src = "assets/default-avatar.svg";
  if (!file) return;
  try {
    const source = await readProfilePhoto(file);
    if (control.files[0] === file && control.isConnected) preview.src = source;
  } catch (failure) {
    if (control.files[0] === file && control.isConnected) {
      error.textContent = failure.message;
      control.value = "";
    }
  }
}

// Completed attendance belongs to an account, never to the shared demo profile.
// Joining reserves a place and does not claim attendance or award a badge.
function personalAttendance() {
  return Array.isArray(user?.attendance) ? user.attendance : [];
}
function personalMetrics(entries, now = new Date()) {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  const weekly = Array(7).fill(0);
  const frequency = {};
  for (const entry of entries) {
    const date = new Date(entry.completedAt);
    if (Number.isNaN(date.getTime())) continue;
    frequency[entry.sport] = (frequency[entry.sport] || 0) + 1;
    if (date >= start && date < end) weekly[(date.getDay() + 6) % 7]++;
  }
  const total = Object.values(frequency).reduce((sum, count) => sum + count, 0);
  return { weekly, frequency, total, tier: 1 + Math.floor(total / 20) };
}
function updatePersonalHome() {
  if (user.id === "demo-dayah") return;
  const metrics = personalMetrics(personalAttendance());
  const days = $(".schedule-days");
  days.replaceChildren();
  if (!joined.length) days.append(cloneTemplate("empty-personal-schedule"));
  for (const index of joined) {
    const sport = sports[index];
    if (!sport) continue;
    const day = cloneTemplate("personal-schedule-day");
    fillText("[data-schedule-date]", sport.date, day);
    fillText("[data-schedule-sport]", sport.sport, day);
    fillText("[data-schedule-time]", sport.time, day);
    fillText("[data-schedule-location]", sport.location + ", Eindhoven", day);
    days.append(day);
  }
  $$(".weekly-log .bar").forEach((bar, index) => {
    $("small", bar).textContent = metrics.weekly[index];
    bar.style.height = Math.max(3, metrics.weekly[index] * 22) + "px";
  });
  fillText(".journey-badge", metrics.tier);
  $(".journey-badge").setAttribute(
    "aria-label",
    "Tier " + metrics.tier + " achievement",
  );
  fillText(".hero-level b", "Tier " + metrics.tier);
}
function updatePersonalProfile() {
  if (user.id === "demo-dayah") return;
  const entries = personalAttendance();
  const metrics = personalMetrics(entries);
  fillText(
    "[data-level-title]",
    metrics.total
      ? "Your progress"
      : $("[data-new-title]", document).textContent,
  );
  fillText("[data-profile-tier]", "#" + metrics.tier);
  fillText("[data-level-count]", metrics.total % 20);
  fillText(
    "[data-level-next]",
    20 -
      (metrics.total % 20) +
      " completed activities until Tier " +
      (metrics.tier + 1),
  );
  $("[data-level-progress]").style.width = (metrics.total % 20) * 5 + "%";
  $$(".frequency > div").forEach((column) => {
    const count = metrics.frequency[$("b", column).textContent.trim()] || 0;
    const labels = $$("small", column);
    labels[0].textContent = count;
    labels[1].textContent =
      (metrics.total ? Math.round((count / metrics.total) * 100) : 0) + "%";
    $(".column", column).style.height = Math.min(150, count * 9) + "px";
  });
  $$(".history").forEach((row) => row.remove());
  const history = $("[data-empty-history]");
  history.hidden = entries.length > 0;
  for (const entry of entries) {
    const row = cloneTemplate("personal-history-row");
    fillText(
      "[data-history-date]",
      new Date(entry.completedAt).toLocaleDateString(),
      row,
    );
    fillText("[data-history-sport]", entry.sport, row);
    fillText("[data-history-location]", entry.location, row);
    history.parentElement.append(row);
  }
  const trophies = $(".trophies");
  trophies.replaceChildren();
  const milestones = [1, 5, 10, 20].filter((count) => count <= metrics.total);
  $("[data-empty-badges]").hidden = milestones.length > 0;
  milestones.forEach((count) => {
    const badge = cloneTemplate("personal-badge");
    fillText(
      "[data-badge-label]",
      count === 1 ? "First activity" : count + " activities",
      badge,
    );
    fillText(
      "[data-badge-count]",
      "Earned through completed attendance",
      badge,
    );
    trophies.append(badge);
  });
}

// Shared event listings and contact directory are public demo data.
// Conversations, relationships and notifications belong to the signed-in account.
function personalChatKey() {
  return "sp-chats-" + (user?.id || "guest");
}
function ownFriendEmails() {
  if (!user) return [];
  if (user.id === "demo-dayah") return friends.map((friend) => friend.email);
  return Array.isArray(user.friendEmails) ? user.friendEmails : [];
}
function loadPersonalContext() {
  const id = user?.id || "guest";
  if (loadedAccountId !== id) {
    loadedAccountId = id;
    chatSelected = 0;
    selected = 0;
    filterOpen = false;
    filters = user?.sports?.length
      ? [...user.sports]
      : sports.map((sport) => sport.sport);
  }
  const seed = user?.id === "demo-dayah" ? read("sp-chats", initialChats) : [];
  chats = read(personalChatKey(), seed);
}
